
    <div class="sub-header">
        <div class="lg-img d-sm-block d-none" style="background: linear-gradient(rgba(0,0,0,0.2) , rgba(0,0,0,0.2)) , url('assets/banners/services-banner.jpg') no-repeat center; background-size: cover;"></div>
        <div class="container">
            <div class="row align-items-center flex-wrap-reverse">
                <div class="sub-header-content col-sm-6 pl-sm-5 pr-sm-4">
                        <h3 class="lato">Contact</h3>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Odit, ab sit! Voluptate distinctio aliquid inventore!</p>
                </div>
                <div class="sub-header-img col-sm-6 d-sm-none d-block"  style="background: linear-gradient(rgba(0,0,0,0.2) , rgba(0,0,0,0.2)) , url('assets/banners/services-banner.jpg') no-repeat center; background-size: cover;">
                </div>
            </div>
            
        </div>
    </div>


   <section></section>
   <section></section>
    